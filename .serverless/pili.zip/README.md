# pili_backend

```
"pili" means "little" in Nahuatl.
```

AWS Lambda based GraphQL endpoint for a simple Short URL service, with an attached DynamoDB table.
